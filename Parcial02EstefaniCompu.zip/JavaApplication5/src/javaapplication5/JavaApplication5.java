/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication5;

/**
 *
 * @author jnadi
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String pass = javax.swing.JOptionPane.showInputDialog(null, "Ingresar contraseña:");
        if (pass != null && pass.equals("1234567")) {
            javax.swing.JOptionPane.showMessageDialog(null, "Bienvenida Estefanía");
              new convertmonedas().setVisible(true);

        }
        else {
            javax.swing.JOptionPane.showMessageDialog(null, "Error 404: Not Found");
            System.exit(0);
        }
    }
    
}
